public class UI implements UIInterface{

    public void showManagementMenu(){
        System.out.println("""
        _______________________________________________
                      Employee Management
        _______________________________________________
        1. Add Employee To Database
        2. Show All Employees in Database
        3. Update Employee
        4. Get Employee By Firstname
        5. Get Employee By Lastname
        6. Get Employee By Birthday
        7. Get Employee By Id
        8. Get Employee By Salary
        9. Get Employee By Department
        10. Delete Employee From Database
        0. Exit
        
        Please choose: """);
    }

    public UI() {


    }
}
