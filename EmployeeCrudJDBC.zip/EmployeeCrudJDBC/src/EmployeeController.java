import java.sql.SQLException;
import java.util.List;

public class EmployeeController implements EmployeeControllerInterface{

    Utilities io;

    UI ui;

    EmployeeDaoJDBCImpl edao;

    public EmployeeController(Utilities io, UI ui, EmployeeDaoJDBCImpl edao) {
        this.io = io;
        this.ui = ui;
        this.edao = edao;
    }


    @Override
    public void runEmployeeManagementProgram() {

        boolean mainLoop = true;

        while (mainLoop) {

            ui.showManagementMenu();

            String choice = io.getStringInput();


            switch (choice) {

                case "1" -> addEmployee();
                case "2" -> showAllEmployees();
                case "3" -> updateEmployee();
                case "4" -> getByFirstNameEmployeeController();
                case "5" -> getByLastNameEmployeeController();
                case "6" -> getByBirthdayEmployeeController();
                case "7" -> getByIdEmployeeController();
                case "8" -> getBySalaryEmployeeController();
                case "9" -> getByDepartmentEmployeeController();
                case "10" -> deleteEmployeeController();
                case "0" -> mainLoop = false;
                default -> System.out.println("Wrong input, please choose 1-9");
            }
        }
    }

    @Override
    public String enterDepartment() {

        String department = "";

        System.out.println("Please enter department");
        System.out.println("1.DBAdmin, 2.Developer, 3.Technician, 4.Marketing, 5.Secretary, 6.Web Designer 7. Chief");
        String choiceDepartment = io.getStringInput();

        switch (choiceDepartment) {
            case "1" -> department = "DBAdmin";
            case "2" -> department = "Developer";
            case "3" -> department = "Technician";
            case "4" -> department = "Marketing";
            case "5" -> department = "Secretary";
            case "6" -> department = "Web Designer";
            case "7" -> department = "Chief";
            default -> System.out.println("Wrong input, please choose option 1-7.");
        }

        return department;
    }

    @Override
    public void addEmployee() {

        Employee e = new Employee();


        System.out.print("Enter First Name: ");
        e.setFirstname(io.getStringInput());

        System.out.print("Enter Last Name: ");
        e.setLastname(io.getStringInput());

        System.out.print("Enter birthday(YYYYMMDD****): ");
        e.setBirthday(io.getIntInput());

        System.out.print("Enter salary: ");
        e.setSalary(io.getDoubleInput());

        e.setDepartment(enterDepartment());

        edao.create(e.getFirstname(), e.getLastname(), e.getBirthday(), e.getSalary(), e.getDepartment());

        System.out.println("Employee has been added to database! ");

    }

    @Override
    public void showAllEmployees(){

        printList(edao.getAll());
    }

    @Override
    public void getByFirstNameEmployeeController() {

        System.out.println("Please enter firstname: ");

       String firstName = io.getStringInput();

        printList(edao.getByFirstName(firstName));



    }

    @Override
    public void printList(List<Employee> list){
        list.forEach(System.out::println);

    }

    @Override
    public void printEmployee(Employee e){

        System.out.println(e);

    }


    @Override
    public void getByLastNameEmployeeController() {

        System.out.println("Please enter lastname: ");

        String lastName = io.getStringInput();

        printList(edao.getByLastName(lastName));

    }

    @Override
    public void getByBirthdayEmployeeController() {


        System.out.println("Please enter range of birthday for database: ");
        System.out.println("(8 numbers)");
        System.out.print("Start: ");
        int start = io.getIntInput();
        System.out.print("End: ");
        int end = io.getIntInput();

        printList(edao.getByBirthday(start, end));


    }



    @Override
    public void getByIdEmployeeController() {

        System.out.println("Please enter id: ");

        int id = io.getIntInput();

        printEmployee(edao.getById(id));


    }

    @Override
    public void getBySalaryEmployeeController() {

        System.out.println("Please enter salary: ");

        double salary = io.getDoubleInput();

       printList(edao.getBySalary(salary));


    }

    @Override
    public void getByDepartmentEmployeeController() {

        String department = enterDepartment();

        printList(edao.getByDepartment(department));


    }

    @Override
    public void updateEmployee() {

        System.out.println("Please enter new employee information");

        System.out.print("Firstname: ");
        String firstName = io.getStringInput();

        System.out.print("Lastname: ");
        String lastName = io.getStringInput();

        System.out.print("id: ");
        int id = io.getIntInput();

        edao.update(firstName, lastName, id);

        System.out.println("Employee has been updated !");


    }

    @Override
    public void deleteEmployeeController() {

        System.out.println("Please enter id of employee you want to delete:");

        int id = io.getIntInput();

        edao.delete(id);

        System.out.println("Employee has been deleted!");


    }


}



