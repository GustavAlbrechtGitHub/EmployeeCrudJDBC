public interface UtilitiesInterface {

    public String fixString(int wantedSize, String stringToFix);


    public String getStringInput();

    public double getDoubleInput();

    public int getIntInput();
}
