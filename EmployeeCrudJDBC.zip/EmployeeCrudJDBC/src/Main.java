import java.sql.SQLException;
import java.util.List;

public class Main {


    public static void main(String[] args) throws SQLException {

        Utilities io = new Utilities();

        UI ui = new UI();

        EmployeeDaoJDBCImpl edao = new EmployeeDaoJDBCImpl();

        EmployeeController ec = new EmployeeController(io, ui, edao);

        ec.runEmployeeManagementProgram();
        

    }

}
