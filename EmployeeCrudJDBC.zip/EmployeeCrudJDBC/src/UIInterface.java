public interface UIInterface {

    public void showManagementMenu();
}
